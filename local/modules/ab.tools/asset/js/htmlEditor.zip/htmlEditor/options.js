/**
 * Created by dremin_s on 28.02.2017.
 */
/** @var o React */
/** @var o ReactDOM */
/** @var o is */
/** @var o $ */
"use strict";

const options = {
	CODE_EDITOR_DIALOG_ID: 'code_editor_dialog',
	DIALOG_PARAMS: {
		title: 'Вставка кода',
		// content: '<div id="ab_code_editor"></div>',
		min_width: 960,
		min_height: 600,
	}
};

export default options;